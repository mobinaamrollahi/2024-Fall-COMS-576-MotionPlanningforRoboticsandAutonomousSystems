Put the following files in the same folder or in your PYTHONPATH
* main.py
* geometry.py
* collisionchecker.py
* planning.py
* Queue.py
* planning.py
* draw_cspace.py

To run the rrt* algorithm:

$ python main.py --alg rrts

To run the rrt algorithm:

$ python main.py --alg rrt

You have to install the networkx library; 
you may want to run the following command: pip install networkx.
