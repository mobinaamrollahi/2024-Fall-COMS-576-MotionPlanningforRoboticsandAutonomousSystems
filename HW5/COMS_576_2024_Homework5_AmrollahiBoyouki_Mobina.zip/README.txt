Put the following files in the same folder or in your PYTHONPATH
* main.py
* geometry.py
* edge.py
* graph.py
* obstacle.py
* planning.py
* queue.py
* draw_cspace.py

For Problem 1 run:

$ python main.py --alg rrt

For Problem 2, run

$ python main.py --alg prm

Please make sure to run the code with python=3.8.5, otherwise there must be some mismatches within the outcome.
